import Navbar from './Navbar'
import About from './about'
import Resume from './Resume'
import Portfolio from './Portfolio'
import Education from './education'
import contact from './Contact'
import './Home.css'
import Contact from './Contact'

const Home = () => {
  return (
    <div className='home '>
      <div className="" >
        <Navbar />
      </div>
      <div className='about'>
        <About />
      </div>
      <div className='resume'>
        <Resume />
      </div>
      <div className='portfolio'>
        <Portfolio />
      </div>
      <div className='education'>
        <Education />
      </div>
      <div className='contact'>
        <Contact />
      </div>
      
    </div>

  );
}

export default Home;
