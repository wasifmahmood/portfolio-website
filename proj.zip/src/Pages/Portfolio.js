import { Link } from 'react-router-dom';
import './portfolio.css';
import MKLOGO from '../image/MK LOGO.png'
import LOGO3 from '../image/logo3.png'

const Portfolio = () => {
  return (
    <div className="Portfolio " >
      <h1>Portfolio</h1>
      <div className='container d-flex'>
        <div className='card'>
          <img src={MKLOGO} />
          <h3 style={{ color: 'orange' }}>Mack's Kitchen</h3>
          <a href="https://github.com/wasifmahmood/MK-Restaurant-UI">https://github.com/wasifmahmood/MK-Restaurant-UI</a>
        </div>
        <div className='card'>
          <img src={MKLOGO} />
          <h3 style={{ color: 'orange' }}>GitHub</h3>
          <a href='https://github.com/wasifmahmood'>https://github.com/wasifmahmood</a>
        </div>
        <div className='card'>
          <img src={LOGO3} />
          <h3 style={{ color: 'orange' }}>Project</h3>
          <a href='https://github.com/yousaf0811/I_learn'>https://github.com/yousaf0811/I_learn</a>
        </div>
      </div>
      <div className='spacer' style={{ color: 'orange' }}>
        <hr className="solid-line" ></hr>
      </div>
    </div>
  );
}

export default Portfolio;
