import './contact.css'




const Contact=()=> {
    return (
      <div className="Contact" >
        <h1>Contact</h1>
        <h3 style={{ color: 'orange' ,paddingTop:'4rem',paddingBottom:'4rem' }}>What did you have for me?</h3><br></br>
      </div>
    );
  }
  
  export default Contact;
  