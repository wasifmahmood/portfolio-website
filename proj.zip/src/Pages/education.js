import './education.css'



const Education = () => {
    return (
        <div className="Education" >
            <h1>Education</h1>
            <div className="data ">
                <h3 >Government College University Faisalabad</h3>
                <span style={{ color: 'orange' }}>Master in Information Technology</span><br></br>
                <span style={{ color: 'orange' }}>GPA(3.02)</span><br></br>
                <span style={{ color: 'orange' }}>2019-2021</span><br></br>
                <span style={{paddingTop:'10px' }}>A Master's in Information Technology (IT) is a two-year program that provides advanced knowledge and skills in the IT field. Students study topics such as programming, database management, network security, and emerging technologies. The program prepares graduates for leadership roles in IT management, software development, cybersecurity, and data analysis.</span>
            </div>
        </div>
    );
}

export default Education;
