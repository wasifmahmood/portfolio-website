import Logo from '../image/Logo.png'
import { FaDownload } from 'react-icons/fa';
import './Navbar.css';

const Navbar = () => {
  return (
    <div className="Navbar p-2 rounded d-flex justify-content-between" style={{ backgroundColor: 'black ' }}>
      <div className='logo'>
        <img src={Logo} width="120" height="40" />
      </div>
      <div className='middle'>
        <span className="a" style={{ color: 'orange' }}>About me</span>
        <span className="b" style={{ color: 'white' }}>Resume</span>
        <span className="c" style={{ color: 'white' }}>Portfolio</span>
        <span className="d" style={{ color: 'white' }}>Contact me</span>
      </div>
      <div className='my-resume '>
        <button type="button" class="btn btn-outline-warning download">
          My Resume <FaDownload />
        </button>
      </div>

    </div>
  );
}

export default Navbar;
